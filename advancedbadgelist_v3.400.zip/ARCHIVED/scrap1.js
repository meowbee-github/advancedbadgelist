            /*let maxArea = width*height
            let area = 0;

            let index = 0;
            const pixelSize = 4;

            while (index < imgData.length) {
                const pixel = imgData.slice(index, index + pixelSize);
                index += pixelSize;

                if (pixel[3] != 0) {
                    area++;
                };
            };

            if (area/maxArea > 0.82) {
                img.style.borderRadius = "0%";
            };*/